# README #

Clone from Repo:
git clone https://username@bitbucket.org/cs3500-Mangos/spreadsheet.git

navigate to your repository

git pull

make any changes

<git status> to see the files you've changed

<git add (file name)> to add the file to your push (you should always add all files)

<git status> again to ensure you've added everything

<git commit -m 'your comment here'> to add a comment to the push (-am works too, was needed to push ps6, don't know why)

<git push> to commit your changes to the repo.